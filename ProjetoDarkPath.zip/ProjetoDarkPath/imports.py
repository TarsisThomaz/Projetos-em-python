from PPlay.window import *
from PPlay.gameimage import *
from PPlay.sprite import *
from PPlay.sound import *
from PPlay.collision import *
import os

VIDAS = 3
HIT = False
TEMPO_INVENCIVEL = 0